---
name: Feature request
about: submit feature / new exploit and any

---

** Exploit (please complete the following information):**
 - Exploit-DB LINK: [e.g. https://www.exploit-db.com/exploits/35385/]
 - LIVE TARGET: [e.g. https://www.localhost/]

** Feature (please complete the following information):**
Please describe what you think is interesting and need to be added in our tools
